import torch
import torch.optim as optim
import torch.nn as nn
from models.vae_model import VAE
from models.gan_model import Generator, Discriminator
from models.rnn_model import RNN

# Initialize models
vae = VAE(300, 64)
generator = Generator(64, 1024)
discriminator = Discriminator(1024)
rnn = RNN(1024, 128, 1024)

# Define loss functions and optimizers
criterion = nn.BCELoss()
vae_optimizer = optim.Adam(vae.parameters(), lr=0.001)
gen_optimizer = optim.Adam(generator.parameters(), lr=0.001)
disc_optimizer = optim.Adam(discriminator.parameters(), lr=0.001)
rnn_optimizer = optim.Adam(rnn.parameters(), lr=0.001)

print("Training initialized...")
