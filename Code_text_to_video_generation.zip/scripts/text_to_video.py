import torch
from models.vae_model import VAE
from models.gan_model import Generator, Discriminator
from models.rnn_model import RNN

class TextToVideoModel:
    def __init__(self, text_dim, latent_dim, video_dim):
        self.vae = VAE(text_dim, latent_dim)
        self.generator = Generator(latent_dim, video_dim)
        self.discriminator = Discriminator(video_dim)
        self.rnn = RNN(video_dim, 128, video_dim)

    def generate_video(self, text_embedding):
        latent, _, _ = self.vae(text_embedding)
        video_frames = self.generator(latent)
        smooth_video = self.rnn(video_frames.unsqueeze(1))
        return smooth_video

model = TextToVideoModel(300, 64, 1024)
print("Model initialized successfully!")
