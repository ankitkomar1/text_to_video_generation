import torch
from models.vae_model import VAE
from models.gan_model import Generator, Discriminator
from models.rnn_model import RNN

vae = VAE(300, 64)
generator = Generator(64, 1024)
discriminator = Discriminator(1024)
rnn = RNN(1024, 128, 1024)

print("Evaluation model loaded successfully!")
